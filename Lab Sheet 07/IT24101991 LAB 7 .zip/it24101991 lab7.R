setwd("C:\\Users\\im45h4\\Desktop\\lab 7")
getwd()




### -------------------------------
### Exercise 1: Uniform distribution [0, 40]
### Scenario: Train arrives anytime between 0 and 40 mins after 8:00
### Task: Find probability it arrives between 10 and 25 mins
### Formula reminder: (x2 - x1) / (max - min)
### -------------------------------
ex1 <- punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)
ex1   # should be around 0.375 if my brain math is right


### -------------------------------
### Exercise 2: Exponential distribution, λ = 2 per hour
### Scenario: Software update time (mean time = 0.5 hours)
### Task: Probability update finishes within 2 hours
### Formula reminder: 1 - exp(-λx)
### -------------------------------
ex2 <- pexp(2, rate = 2)
ex2   # expecting a high probability since 2 hrs is long compared to mean


### -------------------------------
### Exercise 3: Normal distribution, μ = 100, σ = 15
### Scenario: IQ scores
### i) Probability someone has IQ > 130
### ii) Find the IQ score at the 95th percentile
### -------------------------------
# i) Tail probability (above 130)
ex3_i <- pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)
ex3_i

# ii) 95th percentile (score where 95% are below)
ex3_ii <- qnorm(0.95, mean = 100, sd = 15)
ex3_ii

