setwd("C:\\Users\\im45h4\\Desktop\\lab 5")
getwd()


data <- read.table("Data.txt" , header = TRUE , sep = ",")
fix(data)
attach(data)

names(data) <- c("X1" , "x2")
attach(data)
hist(X2,main = "histogran for number of shareholders")


histogram <- hist(X2 ,main = "histogram for number of share holders " , breaks = seq(130,270, length = 8 ),right= FALSE )

breaks <- round(histogram$breaks)
freq <- histogram$counts
mids <- histogram$mids
classes <- c()
for (i in 1:(length(breaks) - 1)) {
  classes[i] <- paste0("[", breaks[i], ",", breaks[i + 1], ")")
}
cbind(Classes = classes, Frequency = freq)


lines(mids, freq)
plot(mids, freq, type = 'l', main = "Frequency polygon for Shareholders", xlab = "Shareholders", ylab = "Frequency", ylim = c(0, max(freq)))



cum.freq <- cumsum(freq)
new <- c()
for (i in 1:length(breaks)) {
  if (i == 1) {
    new[i] <- 0
  } else {
    new[i] <- cum.freq[i - 1]
  }
}
plot(breaks, new, type = 'l', main = "Cumulative Frequency Polygon for Shareholders", xlab = "Shareholders", ylab = "Cumulative Frequency", ylim = c(0, max(cum.freq)))
cbind(Upper = breaks, CumFreq = new)


##exercise  
#1,import dataset
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

#draw histogram with nine class  intervals  
hist(Delivery_Times$Delivery_Time_.minutes. ,
     breaks = seq(20,70,length.out =10 ), 
     right =FALSE,
     main = "histogram  of delivery times ",
     xlab = "delivery  time (minutes)" ,
     ylab = "frequency "
)
# 3. Comment on the shape of the distribution
# The distribution appears to be approximately symmetric with a slight right skew.
# Most delivery times are clustered between 35-55 minutes, with a few outliers on both ends.


# 4. draw cumulative frequency polygon
hist_data <-  hist(Delivery_Times$Delivery_Time_.minutes. ,
                   breaks = seq(20,70,length.out = 10),
                   right = FALSE,
                   plot  = FALSE )

cum.freq <- cumsum(hist_data$counts)
plot(hist_data$breaks, c(0, cum.freq),
     type = 'l',
     main = "cumaltive frequency polygon of delivery times ",
     xlab = "delivery  times(minutes)",
     ylab = "cumulative frequency ")
points(hist_data$breaks, c(0,cum.freq))

